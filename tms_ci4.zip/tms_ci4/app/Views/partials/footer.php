<footer class="bg-dark text-white text-center p-2">
    © <?= date('Y') ?> Transport Management System
</footer>
